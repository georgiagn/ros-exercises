^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_rviz_launchers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.1 (2015-03-23)
------------------
* image_color -> image_rect_color closes `#6 <https://github.com/turtlebot/turtlebot_interactions/issues/6>`_
* Contributors: Jihoon Lee

2.3.0 (2014-12-30)
------------------

2.2.2 (2013-10-25)
------------------

2.2.1 (2013-09-11)
------------------
* Use two separate turtlebot navigation launchers to make things obvious to users.

2.2.0 (2013-08-30)
------------------
* Allow visualizing navigation regardless we use or not application namespaces (with argument use_app_ns).
* Fix view model launcher and dependencies.
* Add bugtracker and repo info URLs.
* Changelogs at package level.


2.1.x - hydro, unstable
=======================

2.1.1 (2013-07-23)
------------------
* Adapt view_navigation configuration to hydro navi stack

2.1.0 (2013-07-16)
------------------
* Catkinized


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_viz/ChangeList
